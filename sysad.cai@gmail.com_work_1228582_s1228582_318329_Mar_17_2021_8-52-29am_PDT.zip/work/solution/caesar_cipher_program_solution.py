# Module Lab 6: Caesar Cipher Program Solution For Instructor
#
# In Module Lab 6, the student is asked to debug 4 different versions of the
# Caesar Cipher program covered in Module Lab 4.
#
# The student should use the debugger to assist them in fixing each version of the
# program.
#
# Below, each bug is commented and along with the correct and incorrect lines.

# Double the given alphabet.
def getDoubleAlphabet(alphabet):
    doubleAlphabet = alphabet + alphabet
    return doubleAlphabet

# Get a message to encrypt.
def getMessage():
    stringToEncrypt = input("Please enter a message to encrypt: ")
    return stringToEncrypt

# Get a cipher key.
def getCipherKey():
    shiftAmount = input("Please enter a key (whole number from 1-25): ")
    return shiftAmount

# Encrypt Message
def encryptMessage(message, cipherKey, alphabet):
    encryptedMessage = ""
    uppercaseMessage = ""
    # Bug #2: The call to upper() is missing.
    uppercaseMessage = message.upper() # Correct
    #uppercaseMessage = message # Incorrect
    for currentCharacter in uppercaseMessage:
        position = alphabet.find(currentCharacter)
        # Bug #1: String isn't being cast to an integer.
        newPosition = position + int(cipherKey) # Correct
        #newPosition = position + cipherKey # Incorrect
        if currentCharacter in alphabet:
            encryptedMessage = encryptedMessage + alphabet[newPosition]
        else:
            encryptedMessage = encryptedMessage + currentCharacter
    return encryptedMessage

# Decrypt Message
def decryptMessage(message, cipherKey, alphabet):
    decryptKey = -1 * int(cipherKey)
    # Bug #3: Passing in cipherKey instead of decryptKey.
    return encryptMessage(message, decryptKey, alphabet) # Correct
    #return encryptMessage(message, cipherKey, alphabet) # Incorrect

# Main program logic.
def runCaesarCipherProgram():
    myAlphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    print(f'Alphabet: {myAlphabet}')
    myAlphabet2 = getDoubleAlphabet(myAlphabet)
    print(f'Alphabet2: {myAlphabet2}')
    myMessage = getMessage()
    print(myMessage)
    myCipherKey = getCipherKey()
    print(myCipherKey)
    myEncryptedMessage = encryptMessage(myMessage, myCipherKey, myAlphabet2)
    print(f'Encrypted Message: {myEncryptedMessage}')
    myDecryptedMessage = decryptMessage(myEncryptedMessage, myCipherKey, myAlphabet2)
    # Bug #4: Printing out the myEncryptedMessage instead of myDecryptedMessage
    print(f'Decrypted Messgae: {myDecryptedMessage}') # Correct
    #print(f'Decrypted Messgae: {myEncryptedMessage}') # Incorrect

# Main Logic
runCaesarCipherProgram()


